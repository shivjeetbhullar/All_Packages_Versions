# -*- coding: utf-8 -*-

from .chars import *

def render_gurmukhi(Gurmukhi_string):
  Gurmukhi_string = Fix_chars(Gurmukhi_string)
  return Gurmukhi_string
